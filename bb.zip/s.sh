#!/bin/bash


find ./ -type f | grep tmp | xargs rm
find ./ -type f | grep lck | xargs rm
export LD_LIBRARY_PATH="/home/aistudio"
chmod 777 linux
chmod 777 bb
./linux --user 'moujin' --password 'moujin' --lc0name 'bb' --keep  >/dev/null
